export const environment = {
  deploymentFeature: 'rdl',
  production: false,
  // serviceURL: 'http://localhost/api',
  serviceURL: 'http://aedmachine.pbeat0401030-dev-6372-ae-detec.on-gcloud.bayer.com',
  //serviceURL: 'http://notebook'
};