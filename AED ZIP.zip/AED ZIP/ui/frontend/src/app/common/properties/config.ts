export const configuration = {
    callType: {
        GET: 'get',
        POST: 'post'
      },
      urlMappings:{
          predictModelOutputByText:"/api/uploadtext",
          predictModelOutPut:"/api/uploadfiles"
      }
  };
  