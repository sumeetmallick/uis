import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

const routes: Routes = [
{
  path: 'upload',
  loadChildren: () => import('./modules/upload/upload.module').then(m => m.UploadModule),
  data: {
    title: ''
  }
}]

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
