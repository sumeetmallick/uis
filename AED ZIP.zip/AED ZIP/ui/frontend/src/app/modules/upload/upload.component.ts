import { Component, OnInit, AfterViewInit, ViewChild} from '@angular/core';
import { from } from 'rxjs';
import {UploadService} from './upload.service';
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import {MatTableModule} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {InputTextModule} from 'primeng/inputtext';
import { SimplePlaceholderMapper } from '@angular/compiler/src/i18n/serializers/serializer';
import * as XLSX from 'xlsx'; 
import * as FileSaver from 'file-saver';
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
import {MessageService} from 'primeng/api';
@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss'],
  providers: [MessageService]
})

export class UploadComponent implements OnInit {
  form : FormGroup
  modelOutput : any
  displayedColumns: string[] = ['confidenceValue','predictedLabel'];
  dataSource: MatTableDataSource<any>;
  loader: boolean = false;
  first = 0;
  selectedType = 'csv';
  rows = 10;
  fileName: String;
  selectionTypes: any = [
    {name: 'csv', type: 'csv'},
    {name: 'Plain Text', code: 'plainText'}
  ];
  selectedInputType: string;
  //tweetText = new FormControl();
  classificationModelOP : any = 
  [
     
  ];
  cols: any[];
  excelDataArr = [];
  disabled: boolean = true;
  validFileExtensions = ["csv"];
  exportColumns: any[];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(
    public fb: FormBuilder,private uploadService: UploadService,
    private messageService: MessageService) { 

      this.form = this.fb.group({
        file: [null],
        tweetText: [],
        threshold: []
      })
      this.form.get('threshold').setValue(0.5);
    }

  ngOnInit(): void {
    this.cols = [
      { field: 'Text', header: 'Text' },
      { field: 'isAdverseEvent', header: 'Is Adverse Event?' },
      { field: 'predictedDrug', header: 'Drug Name' },
      { field: 'predictedReaction', header: 'Reaction' },
      { field: 'summary', header: 'Summary' }
  ];

  this.exportColumns = this.cols.map(col => ({title: col.header, dataKey: col.field}));
  }
  exportExcel() {
    import("xlsx").then(xlsx => {
        const worksheet = xlsx.utils.json_to_sheet(this.excelDataArr);
        const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
        const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
        this.saveAsExcelFile(excelBuffer, "Prediction");
    });
}

saveAsExcelFile(buffer: any, fileName: string): void {
    import("file-saver").then(FileSaver => {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.xlsx';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE
        });
        FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
    });
}
  ngAfterViewInit() {
    // this.dataSource.paginator = this.paginator;
    // this.dataSource.sort = this.sort;
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  getInputType(event){
  console.log(event.target.value);
  this.form.get('tweetText').reset();
  this.form.get('file').reset();
  this.fileName = '';
  this.disabled = true;

  this.selectedType = event.target.value;
  }
  handleFileInput(event){
    console.log(event.target.files[0])
    const formData = new FormData();
    formData.append('file', event.target.files[0]);
  }
  getFileExtension(file){
    return file.name.split(".").pop();
  }
  upload(event) {
  
 
    const file = (event.target as HTMLInputElement).files[0];
    this.fileName = file.name;
    if(this.validFileExtensions.includes(this.getFileExtension(file)) && file.size > 0){
      this.disabled = false;
      console.log(file)
      this.form.patchValue({
        file: file
      });
      this.form.get('file').updateValueAndValidity()
    }else{
      this.showMessage("error","Invalid file type","Make sure the file is not empty or is one of the following formats - "+ this.validFileExtensions.join(","))
      this.disabled = true;
    }
   
 }
 getText(){
   console.log(this.form.get('tweetText').value)
   if(this.form.get('tweetText').value.trim() != ''){
     this.disabled = false;
   }else{
    this.disabled = true;
   }
 }
 showMessage(severity,title,detail){
  setTimeout(() => {
    this.messageService.add({severity:severity, summary:title, detail: detail});
  }, 1000);
 }
 submit() {
  this.loader = true;
  this.disabled = true;
  this.form.get('tweetText').disable();
    //this.exportAsExcelFile(this.classificationModelOP,"AEDetectionPredictedOutPut")
  if (this.selectedType === 'Plain Text'){
    let requestObject = {
      "text": this.form.get('tweetText').value
    };
    var formData: any = new FormData();
    formData.append("text", this.form.get('tweetText').value);
    formData.append("threshold", this.form.get('threshold').value);
    this.uploadService.predictModelOPByText(formData).subscribe((modelOutput) => {
      this.loader = false;
      this.formatOutputAndFormExcel(modelOutput)
    },error => {
      console.log("------>",error);
      this.showError();

    })
  }else{
   
    var formData: any = new FormData();
    console.log(this.form.get('file').value)
    formData.append("file", this.form.get('file').value);
    formData.append("threshold", this.form.get('threshold').value);
    console.log(formData);
    this.uploadService.predictModelOPByFile(formData).subscribe(modelOutput => {
      this.loader = false;
      this.formatOutputAndFormExcel(modelOutput)
    },error => {
      console.log("------>",error);
      this.showError();

    })
  }
}
showError(){
  this.showMessage("error","Server Error","Error has occured from server end");
  this.loader = false;
}
formatOutputAndFormExcel (modelOutput){
  this.disabled = false;
  this.form.get('tweetText').enable();
  this.showMessage("success","Successful","Prediction for selected models has been generated successfully")
  this.classificationModelOP = modelOutput.body;
  this.classificationModelOP.forEach(mapper => {
    let obj = {
      "Text" : mapper.Text,
      "Is Adverse Event": mapper.isAdverseEvent === 0 ? 'No' : 'Yes',
      "Drug Name": mapper.predictedDrug === '' ? 'NA' : mapper.predictedDrug,
      "Reaction": mapper.predictedReaction === '' ? 'NA' : mapper.predictedReaction,
      "Summary": mapper.summary === '' ? 'NA' : mapper.summary
    }
    this.excelDataArr.push(obj);
  })
}
 createDatasource(confidenceValue,index,tweet,groundTruth) {
  
  return {
    confidenceValue: confidenceValue,
    predictedLabel: confidenceValue > 0.5 ? 'True' : 'False',
    tweet: tweet,
    groundTruth: groundTruth,
    id: index+1
  }

}
next() {
  this.first = this.first + this.rows;
}

prev() {
  this.first = this.first - this.rows;
}

reset() {
  this.first = 0;
}

isLastPage(): boolean {
  return this.classificationModelOP ? this.first === (this.classificationModelOP.length - this.rows): true;
}

isFirstPage(): boolean {
  return this.classificationModelOP ? this.first === 0 : true;
}
}
